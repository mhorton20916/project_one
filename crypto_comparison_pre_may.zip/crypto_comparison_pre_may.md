

```python
import requests as req
import json
import pandas as pd
import numpy as np
import datetime
import os
from matplotlib.finance import candlestick2_ohlc
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import seaborn as sns
```


```python
files = os.listdir('historical_data_pre_may')
for file in files:
    if file[0:3]=='BTC':
        btc_df = pd.read_csv('historical_data_pre_may/%s'%file)
        print('BTC dataframe generated')
    elif file[0:3]=='ETH':
        eth_df = pd.read_csv('historical_data_pre_may/%s'%file)
        print('ETH dataframe generated')
    elif file[0:3]=='LTC':
        ltc_df =  pd.read_csv('historical_data_pre_may/%s'%file)
        print('LTC dataframe generated')
btc_df.head()
```

    BTC dataframe generated
    ETH dataframe generated
    LTC dataframe generated
    




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>High</th>
      <th>Low</th>
      <th>Open</th>
      <th>Close</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2013-02-19</td>
      <td>31.30</td>
      <td>28.99</td>
      <td>29.42</td>
      <td>30.25</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2013-02-22</td>
      <td>30.69</td>
      <td>28.00</td>
      <td>30.25</td>
      <td>30.40</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2013-02-25</td>
      <td>34.52</td>
      <td>30.12</td>
      <td>30.40</td>
      <td>33.38</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2013-02-28</td>
      <td>34.90</td>
      <td>32.92</td>
      <td>33.38</td>
      <td>34.50</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2013-03-03</td>
      <td>49.10</td>
      <td>34.19</td>
      <td>34.50</td>
      <td>41.02</td>
    </tr>
  </tbody>
</table>
</div>




```python
fig, ax = plt.subplots()
fig.set_size_inches(w=15,h=8,forward=True)
candlestick2_ohlc(ax,btc_df['Open'],btc_df['High'],btc_df['Low'],btc_df['Close'])
plt.title('OHLC of BTC over 5 years')

num_ticks = 5

inv_ticks = int(len(btc_df['Date'])/num_ticks)
plt.xticks([i for i in range(num_ticks)],[btc_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
plt.show()

```


![png](output_2_0.png)



```python
fig, ax = plt.subplots()
fig.set_size_inches(w=15,h=8,forward=True)
candlestick2_ohlc(ax,eth_df['Open'],eth_df['High'],eth_df['Low'],eth_df['Close'])
plt.title('OHLC of ETH over 5 years')

num_ticks = 5

inv_ticks = int(len(eth_df['Date'])/num_ticks)
plt.xticks([i for i in range(num_ticks)],[eth_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
plt.show()

```


![png](output_3_0.png)



```python
fig, ax = plt.subplots()
fig.set_size_inches(w=15,h=8,forward=True)
candlestick2_ohlc(ax,ltc_df['Open'],ltc_df['High'],ltc_df['Low'],ltc_df['Close'])
plt.title('OHLC of LTC over 5 years')

num_ticks = 5

inv_ticks = int(len(ltc_df['Date'])/num_ticks)
plt.xticks([i for i in range(num_ticks)],[ltc_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
plt.show()
```


![png](output_4_0.png)


# Open flucation analysis (velocity)


```python
btc_differences = list()
eth_differences = list()
ltc_differences = list()

step = 5

for i in range(len(btc_df['Open'])-step):
    btc_differences.append(btc_df['Open'][i+step]-btc_df['Open'][i])
    eth_differences.append(eth_df['Open'][i+step]-eth_df['Open'][i])
    ltc_differences.append(ltc_df['Open'][i+step]-ltc_df['Open'][i])


num_ticks = 5

inv_ticks = int(len(btc_df['Date'])/num_ticks)
    
    
fig, ax = plt.subplots()
plt.plot(btc_differences)
plt.title('Price flucations over %s days for BTC'%str(step))
plt.xticks([i for i in range(num_ticks)],[btc_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
plt.show()
fig, ax = plt.subplots()
plt.plot(eth_differences)
plt.title('Price flucations over %s days for ETH'%str(step))
plt.xticks([i for i in range(num_ticks)],[eth_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
plt.show()
fig, ax = plt.subplots()
plt.plot(ltc_differences)
plt.title('Price flucations over %s days for LTC'%str(step))
plt.xticks([i for i in range(num_ticks)],[ltc_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
plt.show()
```


![png](output_6_0.png)



![png](output_6_1.png)



![png](output_6_2.png)



```python
top20 = int(len(btc_differences)/5)
top_index_btc = sorted(range(len(btc_differences)), key=lambda i: btc_differences[i])[-top20:]
top_btc = [btc_differences[i] for i in top_index_btc]
top_btc[0:5]
```




    [50.639999999999986,
     50.800000000000011,
     51.669999999999959,
     52.060000000000002,
     54.0]



# Open flucation analysis (acceleration)


```python
btc_accel = list()
eth_accel = list()
ltc_accel = list()

step = 5

for i in range(len(btc_differences)-step):
    btc_accel.append(btc_differences[i+step]-btc_differences[i])
    eth_accel.append(eth_differences[i+step]-eth_differences[i])
    ltc_accel.append(ltc_differences[i+step]-ltc_differences[i])

num_ticks = 5

inv_ticks = int(len(btc_df['Date'])/num_ticks)
    
    
fig, ax = plt.subplots()
plt.plot(btc_accel)
plt.title('Price change acceleration over %s days for BTC'%str(step))
plt.xticks([i for i in range(num_ticks)],[btc_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
plt.show()
fig, ax = plt.subplots()
plt.plot(eth_accel)
plt.title('Price change acceleration over %s days for ETH'%str(step))
plt.xticks([i for i in range(num_ticks)],[eth_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
plt.show()
fig, ax = plt.subplots()
plt.plot(ltc_accel)
plt.title('Price change acceleration over %s days for LTC'%str(step))
plt.xticks([i for i in range(num_ticks)],[ltc_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
plt.show()
```


![png](output_9_0.png)



![png](output_9_1.png)



![png](output_9_2.png)



```python
# find sign changes in acceleration analysis
signs = np.sign(btc_accel)
sign_changes_btc = ((np.roll(signs, 1) - signs) != 0).astype(int)
unique, counts = np.unique(sign_changes_btc,return_counts=True)
print(np.asarray((unique, counts)).T)

signs = np.sign(eth_accel)
sign_changes_eth = ((np.roll(signs, 1) - signs) != 0).astype(int)
unique, counts = np.unique(sign_changes_eth,return_counts=True)
print(np.asarray((unique, counts)).T)

signs = np.sign(ltc_accel)
sign_changes_ltc = ((np.roll(signs, 1) - signs) != 0).astype(int)
unique, counts = np.unique(sign_changes_ltc,return_counts=True)
print(np.asarray((unique, counts)).T)
```

    [[  0 381]
     [  1 120]]
    [[  0 447]
     [  1  54]]
    [[  0 394]
     [  1 107]]
    

# Velocity combined with Acceleration Analysis


```python
sign_changes_btc_normalized = np.append(sign_changes_btc,[0,0,0,0,0])
sign_changes_eth_normalized = np.append(sign_changes_eth,[0,0,0,0,0])
sign_changes_ltc_normalized = np.append(sign_changes_ltc,[0,0,0,0,0])

num_ticks = 5

inv_ticks = int(len(btc_df['Date'])/num_ticks)
    
xlist = [i for i in range(len(sign_changes_btc_normalized))]
    
fig, ax = plt.subplots()
plt.plot(btc_differences)
for x in xlist:
    if sign_changes_btc_normalized[x]==1:
        plt.axvline(x=x,linewidth=0.5)
plt.title('Price flucations over %s days for BTC'%str(step))
plt.xticks([i for i in range(num_ticks)],[btc_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
plt.show()
fig, ax = plt.subplots()
plt.plot(eth_differences)
for x in xlist:
    if sign_changes_eth_normalized[x]==1:
        plt.axvline(x=x,linewidth=0.5)
plt.title('Price flucations over %s days for ETH'%str(step))
plt.xticks([i for i in range(num_ticks)],[eth_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
plt.show()
fig, ax = plt.subplots()
plt.plot(ltc_differences)
for x in xlist:
    if sign_changes_ltc_normalized[x]==1:
        plt.axvline(x=x,linewidth=0.5)
plt.title('Price flucations over %s days for LTC'%str(step))
plt.xticks([i for i in range(num_ticks)],[ltc_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
plt.show()

# The above replots the velocity analysis and highlights the detected events with vertical lines
```


![png](output_12_0.png)



![png](output_12_1.png)



![png](output_12_2.png)



```python
# Setting minimum limits for significant event
btc_lim = 50
eth_lim = 3
ltc_lim = 3
 

num_ticks = 5

inv_ticks = int(len(btc_df['Date'])/num_ticks)
    
xlist = [i for i in range(len(sign_changes_btc_normalized))]
    
fig, ax = plt.subplots()
plt.plot(btc_differences)
for x in xlist:
    if sign_changes_btc_normalized[x]==1 and (btc_differences[x]>btc_lim or btc_differences[x]<-btc_lim):
        plt.axvline(x=x,linewidth=0.5)
plt.title('Price flucations over %s days for BTC'%str(step))
plt.xticks([i for i in range(num_ticks)],[btc_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
plt.show()
fig, ax = plt.subplots()
plt.plot(eth_differences)
for x in xlist:
    if sign_changes_eth_normalized[x]==1 and (eth_differences[x]>eth_lim or eth_differences[x]<-eth_lim):
        plt.axvline(x=x,linewidth=0.5)
plt.title('Price flucations over %s days for ETH'%str(step))
plt.xticks([i for i in range(num_ticks)],[eth_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
plt.show()
fig, ax = plt.subplots()
plt.plot(ltc_differences)
for x in xlist:
    if sign_changes_ltc_normalized[x]==1 and (ltc_differences[x]>ltc_lim or ltc_differences[x]<-ltc_lim):
        plt.axvline(x=x,linewidth=0.5)
plt.title('Price flucations over %s days for LTC'%str(step))
plt.xticks([i for i in range(num_ticks)],[ltc_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
plt.show()
```


![png](output_13_0.png)



![png](output_13_1.png)



![png](output_13_2.png)



```python
# Setting additional limits to cut down on noise by only looking at changes after a period of relative stability

btc_lim = 50
eth_lim = 3
ltc_lim = 3
recent_change_lim=3

recent_change_count=0

btc_event_index_list = list()
eth_event_index_list = list()
ltc_event_index_list = list()


num_ticks = 5

inv_ticks = int(len(btc_df['Date'])/num_ticks)
    
xlist = [i for i in range(len(sign_changes_btc_normalized))]
    
fig, ax = plt.subplots()
plt.plot(btc_differences)
for x in xlist:
    if recent_change_count >= recent_change_lim:
        if sign_changes_btc_normalized[x]==1 and (btc_differences[x]>btc_lim or btc_differences[x]<-btc_lim):
            plt.axvline(x=x,linewidth=0.5)
            recent_change_count=0
            btc_event_index_list.append(x)
        else:
            recent_change_count += 1
    else:
        recent_change_count += 1
plt.title('Price flucations over %s days for BTC'%str(step))
plt.xticks([i for i in range(num_ticks)],[btc_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
plt.show()
fig, ax = plt.subplots()
plt.plot(eth_differences)
for x in xlist:
    if recent_change_count >= recent_change_lim:
        if sign_changes_eth_normalized[x]==1 and (eth_differences[x]>eth_lim or eth_differences[x]<-eth_lim):
            plt.axvline(x=x,linewidth=0.5)
            recent_change_count=0
            eth_event_index_list.append(x)
        else:
            recent_change_count += 1
    else:
        recent_change_count += 1
plt.title('Price flucations over %s days for ETH'%str(step))
plt.xticks([i for i in range(num_ticks)],[eth_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
plt.show()
fig, ax = plt.subplots()
plt.plot(ltc_differences)
for x in xlist:
    if recent_change_count >= recent_change_lim:
        if sign_changes_ltc_normalized[x]==1 and (ltc_differences[x]>ltc_lim or ltc_differences[x]<-ltc_lim):
            plt.axvline(x=x,linewidth=0.5)
            recent_change_count=0
            ltc_event_index_list.append(x)
        else:
            recent_change_count += 1
    else:
        recent_change_count += 1
plt.title('Price flucations over %s days for LTC'%str(step))
plt.xticks([i for i in range(num_ticks)],[ltc_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
plt.show()
```


![png](output_14_0.png)



![png](output_14_1.png)



![png](output_14_2.png)



```python
values, counts = np.unique((btc_event_index_list-np.roll(btc_event_index_list,1)),return_counts=True)
print(np.asarray((values, counts)).T)
values, counts = np.unique((eth_event_index_list-np.roll(eth_event_index_list,1)),return_counts=True)
print(np.asarray((values, counts)).T)
values, counts = np.unique((ltc_event_index_list-np.roll(ltc_event_index_list,1)),return_counts=True)
print(np.asarray((values, counts)).T)
```

    [[-423    1]
     [   4    2]
     [   5    5]
     [   6    4]
     [   7    2]
     [   8    1]
     [   9    3]
     [  10    1]
     [  11    1]
     [  12    1]
     [  13    1]
     [  14    1]
     [  19    1]
     [  24    1]
     [  29    1]
     [  39    1]
     [  47    1]
     [  99    1]]
    [[-126    1]
     [  16    1]
     [  24    1]
     [  86    1]]
    [[-407    1]
     [   4    1]
     [   5    1]
     [   7    1]
     [   8    1]
     [  16    1]
     [  43    1]
     [ 324    1]]
    


```python
# The list of indices for significant events doesn't map perfectly to the original data frame, because the data was repeatedly
# aggregated over durations of *step* days.  The indices map to a frame that is 4 items less than the original data frame, so 
# I have added 2 to all elements in order to find the average date of each event
btc_event_index_list_normalized = [x+2 for x in btc_event_index_list]
eth_event_index_list_normalized = [x+2 for x in eth_event_index_list]
ltc_event_index_list_normalized = [x+2 for x in ltc_event_index_list]
```


```python
btc_event_list = list()
eth_event_list = list()
ltc_event_list = list()

for i in btc_event_index_list_normalized:
    btc_event_list.append(btc_df['Date'][i])
for i in eth_event_index_list_normalized:
    eth_event_list.append(btc_df['Date'][i])
for i in ltc_event_index_list_normalized:
    ltc_event_list.append(btc_df['Date'][i])
```


```python
btc_event_list
```




    ['2013-10-14',
     '2013-11-13',
     '2013-11-28',
     '2013-12-25',
     '2014-01-12',
     '2014-02-02',
     '2014-02-20',
     '2014-03-19',
     '2014-04-06',
     '2014-04-21',
     '2014-05-18',
     '2014-09-12',
     '2014-12-08',
     '2014-12-26',
     '2015-10-19',
     '2015-11-27',
     '2016-01-08',
     '2016-05-28',
     '2016-07-24',
     '2016-08-08',
     '2016-10-19',
     '2016-11-09',
     '2016-12-15',
     '2017-01-17',
     '2017-02-01',
     '2017-02-13',
     '2017-03-09',
     '2017-03-24',
     '2017-04-05']




```python
eth_event_list
```




    ['2016-02-22', '2016-05-04', '2016-06-21', '2017-03-06']




```python
ltc_event_list
```




    ['2013-11-19',
     '2013-12-04',
     '2013-12-25',
     '2014-01-18',
     '2014-01-30',
     '2014-03-19',
     '2014-07-26',
     '2017-03-24']



# Plotting significant dates across all tracked cyrpto currencies


```python
plt.plot(btc_differences,'b')
plt.plot(eth_differences,'r')
plt.plot(ltc_differences,'g')
plt.legend(['BTC','ETH','LTC'])
plt.show()
```


![png](output_22_0.png)



```python
# Normalizing Axes
btc_differences_normalized = [x/max(btc_differences) for x in btc_differences]
eth_differences_normalized = [x/max(eth_differences) for x in eth_differences]
ltc_differences_normalized = [x/max(ltc_differences) for x in ltc_differences]

plt.plot(btc_differences_normalized,'b')
plt.plot(eth_differences_normalized,'r')
plt.plot(ltc_differences_normalized,'g')
plt.legend(['BTC','ETH','LTC'])
plt.show()
```


![png](output_23_0.png)



```python
datetime_list_btc = [datetime.datetime.strptime(x,'%Y-%m-%d') for x in btc_event_list]
ordinal_list_btc = [x.toordinal() for x in datetime_list_btc]
datetime_list_eth = [datetime.datetime.strptime(x,'%Y-%m-%d') for x in eth_event_list]
ordinal_list_eth = [x.toordinal() for x in datetime_list_eth]
datetime_list_ltc = [datetime.datetime.strptime(x,'%Y-%m-%d') for x in ltc_event_list]
ordinal_list_ltc = [x.toordinal() for x in datetime_list_ltc]

ax = sns.distplot(ordinal_list_btc)
ax.set_xlim(left=datetime.datetime.strptime(btc_df['Date'][0], '%Y-%m-%d').toordinal(),right=datetime.datetime.strptime(btc_df['Date'].iloc[-1], '%Y-%m-%d').toordinal())
x_ticks = ax.get_xticks()
ax.set_xticks(x_ticks[::2])
xlabels = [datetime.datetime.fromordinal(int(x)).strftime('%Y-%m-%d') for x in x_ticks[::2]]
ax.set_xticklabels(xlabels)
plt.title('Frequency plot of important dates for BTC')
plt.show()

ax = sns.distplot(ordinal_list_eth)
ax.set_xlim(left=datetime.datetime.strptime(btc_df['Date'][0], '%Y-%m-%d').toordinal(),right=datetime.datetime.strptime(btc_df['Date'].iloc[-1], '%Y-%m-%d').toordinal())
x_ticks = ax.get_xticks()
ax.set_xticks(x_ticks[::2])
xlabels = [datetime.datetime.fromordinal(int(x)).strftime('%Y-%m-%d') for x in x_ticks[::2]]
ax.set_xticklabels(xlabels)
plt.title('Frequency plot of important dates for ETH')
plt.show()

ax = sns.distplot(ordinal_list_ltc)
ax.set_xlim(left=datetime.datetime.strptime(btc_df['Date'][0], '%Y-%m-%d').toordinal(),right=datetime.datetime.strptime(btc_df['Date'].iloc[-1], '%Y-%m-%d').toordinal())
x_ticks = ax.get_xticks()
ax.set_xticks(x_ticks[::2])
xlabels = [datetime.datetime.fromordinal(int(x)).strftime('%Y-%m-%d') for x in x_ticks[::2]]
ax.set_xticklabels(xlabels)
plt.title('Frequency plot of important dates for LTC')
plt.show()
```


![png](output_24_0.png)



![png](output_24_1.png)



![png](output_24_2.png)


# VIX comparison


```python
vix_df = pd.read_csv('historical_data_pre_may/vixcurrent.csv',header=1)
vix_df = vix_df.drop([x for x in range(vix_df.index[vix_df['Date']=='04/28/2017'].tolist()[0],len(vix_df['Date']))])
vix_df = vix_df.drop([x for x in range(vix_df.index[vix_df['Date']=='2/19/2013'].tolist()[0])])

vix_df.reset_index(inplace=True,drop=True)
vix_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>VIX Open</th>
      <th>VIX High</th>
      <th>VIX Low</th>
      <th>VIX Close</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2/19/2013</td>
      <td>12.81</td>
      <td>12.85</td>
      <td>12.08</td>
      <td>12.31</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2/20/2013</td>
      <td>12.32</td>
      <td>14.68</td>
      <td>12.32</td>
      <td>14.68</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2/21/2013</td>
      <td>14.68</td>
      <td>16.21</td>
      <td>14.67</td>
      <td>15.22</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2/22/2013</td>
      <td>14.60</td>
      <td>15.02</td>
      <td>14.16</td>
      <td>14.17</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2/25/2013</td>
      <td>13.69</td>
      <td>19.28</td>
      <td>13.57</td>
      <td>18.99</td>
    </tr>
  </tbody>
</table>
</div>




```python
fig, ax = plt.subplots()
fig.set_size_inches(w=15,h=8,forward=True)
candlestick2_ohlc(ax,vix_df['VIX Open'],vix_df['VIX High'],vix_df['VIX Low'],vix_df['VIX Close'])
plt.title('OHLC of VIX over 5 years')

num_ticks = 5

inv_ticks = int(len(vix_df['Date'])/num_ticks)
plt.xticks([i for i in range(num_ticks)],[vix_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
plt.show()
```


![png](output_27_0.png)



```python
# Finding times when the VIX was unusually high
vix_threshold = 22
last_index=0

high_vix = pd.DataFrame(vix_df[['Date','VIX Open']][vix_df['VIX Open']>=vix_threshold])
high_vix.reset_index(inplace=True)

unique_high_vix = pd.DataFrame(columns=[['Date','Open']])

# Finds dates when the VIX rises above the threshold, then stops checking until the next time it stabilizes
for index, date, val in high_vix.values:
    if(index==last_index+1):
        last_index=index
    else:
        unique_high_vix.set_value(index=index,col='Date',value=date)
        unique_high_vix.set_value(index=index,col='Open',value=val)
        last_index=index

unique_high_vix
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Open</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>417</th>
      <td>10/14/2014</td>
      <td>23.77</td>
    </tr>
    <tr>
      <th>421</th>
      <td>10/20/2014</td>
      <td>22.11</td>
    </tr>
    <tr>
      <th>461</th>
      <td>12/16/2014</td>
      <td>23.55</td>
    </tr>
    <tr>
      <th>480</th>
      <td>01/14/2015</td>
      <td>22.87</td>
    </tr>
    <tr>
      <th>482</th>
      <td>01/16/2015</td>
      <td>22.8</td>
    </tr>
    <tr>
      <th>632</th>
      <td>08/21/2015</td>
      <td>22.55</td>
    </tr>
    <tr>
      <th>651</th>
      <td>09/18/2015</td>
      <td>23.07</td>
    </tr>
    <tr>
      <th>653</th>
      <td>09/22/2015</td>
      <td>22.97</td>
    </tr>
    <tr>
      <th>657</th>
      <td>09/28/2015</td>
      <td>25.02</td>
    </tr>
    <tr>
      <th>711</th>
      <td>12/14/2015</td>
      <td>24.7</td>
    </tr>
    <tr>
      <th>724</th>
      <td>01/04/2016</td>
      <td>22.48</td>
    </tr>
    <tr>
      <th>727</th>
      <td>01/07/2016</td>
      <td>23.22</td>
    </tr>
    <tr>
      <th>732</th>
      <td>01/14/2016</td>
      <td>24.75</td>
    </tr>
    <tr>
      <th>746</th>
      <td>02/04/2016</td>
      <td>22.29</td>
    </tr>
    <tr>
      <th>759</th>
      <td>02/24/2016</td>
      <td>22.28</td>
    </tr>
    <tr>
      <th>844</th>
      <td>06/24/2016</td>
      <td>26.06</td>
    </tr>
  </tbody>
</table>
</div>




```python
datetime_list_vix = [datetime.datetime.strptime(x,'%m/%d/%Y') for x in unique_high_vix['Date']]
ordinal_list_vix = [x.toordinal() for x in datetime_list_vix]
ax = sns.distplot(ordinal_list_vix)
ax.set_xlim(left=datetime.datetime.strptime(vix_df['Date'][0], '%m/%d/%Y').toordinal(),right=datetime.datetime.strptime(vix_df['Date'].iloc[-1], '%m/%d/%Y').toordinal())
x_ticks = ax.get_xticks()
ax.set_xticks(x_ticks[::2])
xlabels = [datetime.datetime.fromordinal(int(x)).strftime('%Y-%m-%d') for x in x_ticks[::2]]
ax.set_xticklabels(xlabels)
plt.title('Frequency plot of important dates for VIX')
plt.show()
```


![png](output_29_0.png)



```python
# vix_differences = list()

# step = 5

# for i in range(len(vix_df['VIX Open'])-step):
#     vix_differences.append(vix_df['VIX Open'][i+step]-vix_df['VIX Open'][i])
    


# num_ticks = 5

# inv_ticks = int(len(vix_differences)/num_ticks)
    
    
# fig, ax = plt.subplots()
# plt.plot(vix_differences)
# plt.title('Value flucations over %s days for VIX'%str(step))
# plt.xticks([i for i in range(num_ticks)],[vix_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
# ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
# plt.show()

# vix_accel = list()

# step = 5

# for i in range(len(vix_differences)-step):
#     vix_accel.append(vix_differences[i+step]-vix_differences[i])

# num_ticks = 5

# inv_ticks = int(len(vix_differences)/num_ticks)
    
    
# fig, ax = plt.subplots()
# plt.plot(vix_accel)
# plt.title('Value change acceleration over %s days for VIX'%str(step))
# plt.xticks([i for i in range(num_ticks)],[vix_df['Date'][inv_ticks*i] for i in range(num_ticks+1)])
# ax.xaxis.set_major_locator(ticker.MaxNLocator(num_ticks))
# plt.show()
```
